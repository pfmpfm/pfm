> 请检查PR是否满足[《代码合入流程指导和规范》](https://gitee.com/openharmony/powermgr_power_manager/wikis/issue-commit-pr-standard) , 否则将不会审查通过。

**【关联Issue】**


**【修改描述】**


**【验证结果】**

